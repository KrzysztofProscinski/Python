# method 1:
dict1 = {}
dict1["I"]=1
dict1["IV"]=4
dict1["V"]=5
dict1["IX"]=9
dict1["X"]=10
dict1["XL"]=40
dict1["L"]=50
dict1["XC"]=90
dict1["C"]=100
dict1["CD"]=400
dict1["D"]=500
dict1["CM"]=900
dict1["M"]=1000

# method 2:
dict2 = {"I": 1, "IV": 4, "V": 5, "IX": 9, "X": 10, "XL": 40, "L": 50, "XC": 90, "C": 100, "CD": 400, "D": 500, "CM": 900, "M": 1000}

# method 3:
dict3 = dict([("I",1),("IV",4),("V",5),("IX",9),("X",10),("XL",40),("L",50),("XC",90),("C",100),("CD",400),("D",500),("CM",900),("M",1000)])
