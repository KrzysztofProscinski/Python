#creating integer
x = int("14792456902479457890456712368014671458923789013409")

print("Our integer is:", x)

#converting to string
sx = str(x)

#number of zeros
no0 = sx.count("0")

print("Number of zeros is:", no0)
