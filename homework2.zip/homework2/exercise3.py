s=sum([x ** 2 for x in range(1, 2022)])

print(s)
