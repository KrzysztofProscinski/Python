# let's define this string as content of the table from previous exercise:
S = " No. \t Name (en) \t Symbol  Weight (u) \n 1 \t Hydrogen \t H \t 1 \n 2 \t Helium \t He \t 4 \n 3 \t Lithium \t Li \t 7 \n 4 \t Berylium \t Be \t 9 \n 5 \t Boron \t \t B \t 11 \n 6 \t Carbon \t C \t 12 \n 7 \t Nitrogen \t N \t 14 \n 8 \t Oxygen \t O \t 16 \n 9 \t Fluorine \t F \t 19 \n 10 \t Neon \t \t Ne \t 20"
print(S)

# number of black characters:
S_len = len(S)
no_bchar=sum([not S[i].isspace() for i in range(0,S_len)])
print("Black characters: ",no_bchar)

# number of words:
words=S.split()
no_words=len(words)
print("Words: ",no_words)

# longest word:
print("Longest word: ",max(words,key=len))

# sorting according to lexicographic order:
print("Words sorted in lexicographic order:")
words.sort(reverse=False)
for i in range(0,no_words):
    print(words[i])

# sorting according to the length:
print("Words sorted according to the length:")
words.sort(reverse=False,key=len)
for i in range(0,no_words):
    print(words[i])
