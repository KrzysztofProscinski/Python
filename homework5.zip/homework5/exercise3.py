import random

def  random_walk(start):
    random.seed()       # seed
    position = start    # starting position
    movement = 0        # movement (randomly chosen later)
    i=0
    while i < 100:
        movement = random.choice([-1, 1])   # random choice of movement
        position = position+movement
        yield position                      # position after movement
        i = i + 1


print("random walk:")
for position in random_walk(0):
    print(position)
