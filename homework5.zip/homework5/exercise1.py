import os

def find_pdf_size(top):
    pdf_bytes = 0  # number of bytes
    for root, dirs, files in os.walk(top):
       for name in files:
            if name.lower().endswith(".pdf"):   # including only .pdf files
                pdf_bytes = pdf_bytes + os.path.getsize(os.path.join(root, name))
    print(pdf_bytes)




find_pdf_size(".")
