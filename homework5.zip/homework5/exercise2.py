import datetime
from datetime import timedelta, date
from datetime import datetime

def print_working_days(date1, date2):
    datetime1 = datetime.strptime(date1, '%Y-%m-%d').date() # converting string to datetime format
    datetime2 = datetime.strptime(date2, '%Y-%m-%d').date()
    date0 = datetime1   # date0 is iterated from date1 to date2 
    print(date0)    # including date1
    while date0 < datetime2:
        date0 = date0 + timedelta(days=1)
        if date0.weekday()==5 or date0.weekday()==6:    # excluding weekends
            continue
        if date0 == datetime2:  # excluding date2
            continue
        print(date0)
    return 0


print_working_days("2023-3-10", "2023-3-27")
