class Vector:

    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z

    def __repr__(self):        # return string "Vector(x, y, z)"
        return str('Vector(',self.x,', ',self.y,', ',self.z,')')

    def __eq__(self, other):  # v == w
        return self.x==other.x and self.y==other.y and self.z==other.z

    def __ne__(self, other):        # v != w
        return not self == other

    def __add__(self, other):   # v + w
        add_x = self.x+other.x
        add_y = self.y+other.y
        add_z = self.z+other.z
        return Vector(add_x, add_y, add_z)

    def __sub__(self, other):   # v - w
        sub_x = self.x-other.x
        sub_y = self.y-other.y
        sub_z = self.z-other.z
        return Vector(sub_x,sub_y,sub_z)

    def __mul__(self, other):  # return the dot product (number)
        mul_x = self.x*other.x
        mul_y = self.y*other.y
        mul_z = self.z*other.z
        return mul_x + mul_y + mul_z

    def cross(self, other):   # return the cross product (Vector)
        cr_x = self.y*other.z-self.z*other.y
        cr_y = self.z*other.x-self.x*other.z
        cr_z = self.x*other.y-self.y*other.x
        return Vector(cr_x,cr_y,cr_z)

    def length(self):   # the length of the vector
        lenght = math.sqrt(self.x*self.x+self.y*self.y+self.z*self.z)
        return lenght

    def __hash__(self):   # we assume that vectors are immutable
        return hash((self.x, self.y, self.z))

# Exemplary tests. Change values in your tests.
import math
v = Vector(1, 1, 1)
w = Vector(4, 2, -2)
assert v != w
assert v + w == Vector(5, 3, -1)
assert v - w == Vector(-3, -1, 3)
assert v * w == 4
assert v.cross(w) == Vector(-4, 6, -2)
assert v.length() == math.sqrt(3)
S = set([v, v, w])
assert len(S) == 2

print("Tests passed")
