import numpy as np 

# (a) float from 0.0 to 1.0 step 0.1, shape=(11,),

list1 = np.linspace(0., 1., num=11, dtype=float)
list1.shape=(11,)

print("(a): \n", list1)

# (b) int zeros (1 byte) with shape=(5,6),

list2 = np.zeros( (5, 6), dtype=int )

print("(b): \n", list2)

# (c) complex with shape=(9,), powers of x = complex(0, 1): 1, x, x**2, ..., x**8. 

x = complex(0, 1)

list3_a = np.linspace(0., 8, num=9, dtype=float)   # additional list containing powers of x

list3 = np.power(x, list3_a).astype(complex)
list3.shape=(9,)

print("(c): \n", list3)
