import numpy as np 

# (a) Create a two dimensional array called m1, shape=(4,5).

m1 = np.arange(20).reshape((4,5))

print("(a): \n", m1) 

# (b) Create a new array m2 from m1, in which the elements of each row are in reverse order.

m2 = m1[::1,::-1]

print("(b): \n", m2) 

# (c) Create a new array m3 from m1, in which the elements of each column are in reverse order.

m3 = m1[::-1,::1]

print("(c): \n", m3) 

# (d) Cut of the first and last row and the first and last column of m1.

m4 = m1[1:3,1:4]

print("(d): \n", m4)
