import numpy as np 

# (a) Create an arbitrary one dimensional array called v1.

v1 = np.arange(10)

print("(a): \n",v1)

# (b) Create a new array v2 which consists of the odd indices of v1.

v2 = v1[1::2]

print("(b): \n",v2)

# (c) Create a new array v3 in backwards ordering from v1.

v3 = v1[::-1]

print("(c): \n",v3)

