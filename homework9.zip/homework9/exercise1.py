import numpy as np
import matplotlib.pyplot as plt

x = np.linspace(0,10,1000)
a = 1.0
y1 = np.sin(x) # functions which have to be plotted
y2 = np.cos(x)
y3 = np.exp(-x)

plt.plot(x, y1, color='r', linestyle='solid', label='sin(x)') # plotting
plt.plot(x, y2, color='g', linestyle='dashed', label='cos(x)')
plt.plot(x, y3, color='b', linestyle='dotted', label='exp(-x)')

plt.legend() # adding legend

plt.show()
