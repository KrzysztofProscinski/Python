import matplotlib.pyplot as plt
import numpy as np
import random

random.seed()

all_points = [(random.random(), random.random()) for i in range(100)] # filling list with pairs of random numbers

x = [p[0] for p in all_points] # x coordinates
y = [p[1] for p in all_points] # y coordinates

sizes = [(p[0]+p[1])*10 for p in all_points] # sizes of points

colors = np.array(['r' for _ in range(100)]) # colors of points (defautly red)

j=0

for p in all_points:
    if np.sqrt(p[0]*p[0]+p[1]*p[1])<1:
        colors[j]='g' # points are green for certain distances
    j=j+1

plt.scatter(x, y, sizes, c=colors)

plt.show()
