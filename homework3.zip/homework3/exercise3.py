# iporting needed libraries
import math

# defining things
n = 2022
x = format(math.pi,'.5f')
word = "Python"
polish = "książka"

# writing to file
file_out = open("vars.txt","w")
file_out.write("{}\n{}\n{}\n{}\n".format(n, x, word, polish))
file_out.close()

# reading from file
file_in = open("vars.txt","r")
R=file_in.read()
print(R)
