# solution with "for" loop
for i in range(1,41):
    if i==13:
        continue;
    elif i%35==0:
        print(i,"is divided by 5 and 7")
    elif i%5==0:
        print(i,"is divided by 5")
    elif i%7==0:
        print(i,"is divided by 7")
    else:
        print(i,"is not important")

# solution with "while" loop
j=1

while j<41:
    if j==13:
        j=j+1
    elif j%35==0:
        print(j,"is divided by 5 and 7")
    elif j%5==0:
        print(j,"is divided by 5")
    elif j%7==0:
        print(j,"is divided by 7")
    else:
        print(j,"is not important")
    j=j+1
