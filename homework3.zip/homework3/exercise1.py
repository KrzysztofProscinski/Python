text="Krzysztof"

for char in text:
    print("+---", end="")
print("+")

for char in text:
    print("|",char,"",end="")
print("|")

for char in text:
    print("+---",end="")
print("+")
