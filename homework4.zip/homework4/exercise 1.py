# coordinates for (a) and (b)
X = 1
Y = 0
# list for (c) and (d)
L = [(2, 1), (3, 0.5), (5, -2), (-6, 6), (3, 1), (3, 2), (-6,5)]

# (a)
circle_test = lambda x, y: True if x*x+y*y==1 else False
print ("is p=(",X,",",Y,") in unit circle: \n", circle_test(X, Y) )

# (b)
positive_test = lambda x, y: True if x>0 and y>0 else False
print ("are the coordinates of p=(",X,",",Y,") positive: \n", positive_test(X, Y) )

# (c)
L.sort(key=lambda p: (-p[0], p[1]))
print("Sorting list according according t decreasing X and increasing Y: \n", L)


# (d)
L.sort(key=lambda p: (abs(p[0])+abs(p[1])))
print("Sorting list according to sum of X and Y: \n", L)
