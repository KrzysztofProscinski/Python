# (a)
def iter_even():
    i = 0
    while True:
        yield i
        i += 2

# (b)
def iter_odd():
    i = 1
    while True:
        yield i
        i += 2

# (c)
def iter_power(k):
    i = 1
    while True:
        yield pow(k,i)
        i += 1

# testing
print("iter_even test:")
for i in iter_even():
    print(i)
    if i > 10:
        break

print("iter_odd test:")
for i in iter_odd():
    print(i)
    if i > 10:
        break

power_base = 2

print("iter_power test for k=",power_base,":")
for i in iter_power(power_base):
    print(i)
    if i > 100:
        break
