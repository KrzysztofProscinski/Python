# lists
alphabet = ["a","b","c","d","e","f","g","h","i","j"]
L = [0,1,2,3,4,5,6,7,8,9]

print("alphabet list: \n",alphabet)
print("number list: \n",L)

# iterative version
def reverse_range_iterative(list,left,right):
    list1=list[len(list):0:-1]
    for i in range(0,len(list)):
        if i>=left and i<right+1:
            list[i] = list1[i]
    return list

# recursive version
def reverse_range_recursive(list,left,right):
    if left>=right:
        return list

    x = list[left]
    list[left]=list[right]
    list[right] = x
    list = reverse_range_recursive(list,left+1,right-1)

    return list

# printing
reverse_range_iterative(alphabet,3,6)
reverse_range_recursive(L,3,6)

print("reversed alphabet list: \n",alphabet)
print("reversed number list: \n",L)
