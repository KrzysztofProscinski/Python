import numpy as np
import pandas as pd

names = ['Hydrogen','Helium','Lithium','Berylium','Boron','Carbon','Nitrogen','Oxygen','Fluorine','Neon']
symbols = ['H','He','Li','Be','B','C','N','O','F','Ne']
weighs = [1,4,7,9,11,12,14,16,19,20]

df1 = pd.DataFrame({"Name":names, "Symbol":symbols, "Weigh":weighs})
df1.index = [1,2,3,4,5,6,7,8,9,10]

print(df1)
