import numpy as np
import pandas as pd

from numpy import random

# index - days
days = pd.date_range(start="2023-05-01",end="2023-05-31")

# data - random numbers
numbers = random.randint(100, size=(31))

s1 = pd.Series(data=numbers, index=days, dtype=None, name="Date series", copy=False)
print(s1)
