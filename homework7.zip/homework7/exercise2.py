import itertools
import random

# (a) returning 0, 1, 0, 1, 0, 1, ...,

print("(a):")

iter_a = itertools.cycle('01')  # iterator definition

for i in range(10):         # number of printed items
    print(next(iter_a))     # printing
        

# (b) returning randomly 0 or 1 on demand,

print("\n(b):")

iter_b = itertools.cycle('01')  # iterator definition

for i in range(10):                 # number of printed items
    ra = next(iter_b)               # taking two next iterated items
    rb = next(iter_b)               # one of them must be 1, and the second must be 0
    print(random.choice([ra,rb]))   # randomly choosing between 0 and 1

# (c) returning 0, 1, 0, -1, 0, 1, 0, -1, ...

print("\n(c):")

list_c = ['0','1','0','-1']
iter_c = itertools.cycle(list_c)  # iterator definition

for i in range(10):         # number of printed items
    print(next(iter_c))     # printing
