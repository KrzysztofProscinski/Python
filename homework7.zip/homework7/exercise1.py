import math

# Vector class definition
class Vector:

    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z

    def __repr__(self):        # return string "Vector(x, y, z)"
        return str('Vector(',self.x,', ',self.y,', ',self.z,')')

    def __eq__(self, other):  # v == w
        return self.x==other.x and self.y==other.y and self.z==other.z

    def __ne__(self, other):        # v != w
        return not self == other

    def __add__(self, other):   # v + w
        add_x = self.x+other.x
        add_y = self.y+other.y
        add_z = self.z+other.z
        return Vector(add_x, add_y, add_z)

    def __sub__(self, other):   # v - w
        sub_x = self.x-other.x
        sub_y = self.y-other.y
        sub_z = self.z-other.z
        return Vector(sub_x,sub_y,sub_z)

    def __mul__(self, other):  # return the dot product (number)
        mul_x = self.x*other.x
        mul_y = self.y*other.y
        mul_z = self.z*other.z
        return mul_x + mul_y + mul_z

    def cross(self, other):   # return the cross product (Vector)
        cr_x = self.y*other.z-self.z*other.y
        cr_y = self.z*other.x-self.x*other.z
        cr_z = self.x*other.y-self.y*other.x
        return Vector(cr_x,cr_y,cr_z)

    def length(self):   # the length of the vector
        lenght = math.sqrt(self.x*self.x+self.y*self.y+self.z*self.z)
        return lenght

    def __hash__(self):   # we assume that vectors are immutable
        return hash((self.x, self.y, self.z))
# end of class definition


# function
def find_axis(v1,v2):    
    v3=Vector.cross(v1,v2)      # the perpendicular vector is cross product of vectors v1 and v2
    if(v3==Vector(0,0,0)):      # exception
        raise ValueError("parallel vectors")
    else:
        v3_len = Vector.length(v3)  # length to further normalization
        v3_x = v3.x
        v3_y = v3.y
        v3_z = v3.z
        v3_unit = Vector(v3_x/v3_len,v3_y/v3_len,v3_z/v3_len)   # normalized vector
        return v3_unit


# test
v = Vector(1,1,0)
w = Vector(0,0,2)

axis = find_axis(v,w)
print(axis.x, axis.y, axis.z)
